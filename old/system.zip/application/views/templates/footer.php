<div class="container-fluid" style="padding: 0px; overflow: hidden;">
<div class="footer">
<div class="row">
    <div class="col-md-12">
        <ul class="list-unstyled list-inline social text-center">
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-facebook"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-twitter"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-instagram"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();"><i class="fa fa-google-plus"></i></a></li>
            <li class="list-inline-item"><a href="javascript:void();" target="_blank"><i class="fa fa-envelope"></i></a></li>
        </ul>
    </div>
    </hr>
</div>
<div class="row">
    <div class="col-md-12">
        <span class="cp"> (c) IPC Harvest Church, Whitefield, Bangalore | Site Developed & Maintained by <a href="https://www.igensoftware.com"> Igen Software Solutions</a></span>

    </div>

</div>
</div>
</div>
</body>
</html>
