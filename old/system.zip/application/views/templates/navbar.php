    <div class="row">

        <div class="col-md-12">
            <div class="container tophead">
            <div class="navbar navbar-igen navbar-fixed-top" role="navigation">

                    <div class="igen-nav">
                        <div class="navbar-header">

                                <img src="<?php echo base_url(); ?>assets/images/logo-white.png" class="logo">

                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>

                        </div>
                        <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav pull-right">

                        <li class="active"><a href="index.html">HOME</a> </li>
                        <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown" href="#">ABOUT<span class="caret"></span> </a>
                            <ul class="dropdown-menu">
                                <li><a href="#"> History</a></li>
                                <li class="divider"></li>
                                <li><a href="#"> History</a></li>
                                <li class="divider"></li>
                                <li><a href="#"> History</a></li>
                                <li class="divider"></li>
                                <li><a href="#"> History</a></li>
                            </ul>
                        </li>
                        <li><a href="index.html">MINISTRIES<span class="caret"></span></a> </li>
                        <li><a href="index.html">VIDEOS<span class="caret"></span></a> </li>
                        <li><a href="index.html">BLOG</a> </li>
                        <li><a href="index.html">AUDIO<span class="caret"></span></a> </li>
                        <li><a href="index.html">CONTACT US</a> </li>
                    </ul>
                        </div>
                    </div>
                </div>

        </div>
    </div>
    </div>
</div>
