<style>

@media (min-width: 769px){

	.content-wrapper {

    display: unset;

    vertical-align: top;

}

}

</style>



<!-- Main content -->

			<div class="content-wrapper">



				<!-- Content area -->

				<div class="content">



					<!-- Main charts -->

					<div class="row">

						<div class="col-lg-12">



							<!-- Traffic sources -->

							<div class="panel panel-flat">

								<div class="panel-heading" style="background-color: #26a69a36;border: 2px solid #26a69a36;color: #263238;">
								<!--<div class="panel-heading" style="background-color: #ffdcdc;border: 2px solid #e23f3f;color: #263238;">-->

									<h6 class="panel-title text-center" style="font-size: 20px;font-weight: 700; min-height:50px;">Welcome to Sanctuary Church Management System V 3.0<br /></h6>
									<h6 class="panel-title text-center" style="font-size: 14px;font-weight: 700; min-height:500px;">This Product is Licensed to IPC Harvest Church, Whitefield<br />License No. Z32/2017/12</h6>

								</div>



								<div class="position-relative" id="traffic-sources"></div>

							</div>

							<!-- /traffic sources -->



						</div>

					</div>

					<!-- /main charts -->





					



					



				</div>

				<!-- /content area -->



			</div>

			<!-- /main content -->
