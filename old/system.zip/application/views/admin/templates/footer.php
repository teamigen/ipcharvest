
					<!-- Footer -->
					<div class="footer text-muted">
						&copy; 2018. <a href="#">Sanctuary Church Solutions</a> by <a href="http://igensoftware.com" target="_blank">Igen Software Solutions</a>
					</div>
					<!-- /footer -->

				</div>
				<!-- /content area -->

			</div>
			<!-- /main content -->
		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>
</html>
